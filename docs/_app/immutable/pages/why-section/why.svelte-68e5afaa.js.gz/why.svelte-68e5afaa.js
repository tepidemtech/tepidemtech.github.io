import{S,i as W,s as j,y as k,z as A,A as E,r as N,p as P,D as q,e as a,t as l,c as s,a as w,h,d as $,b as x,g as B,K as n,n as R}from"../../chunks/index-b450546e.js";import{S as z}from"../../chunks/section-8cc96ac0.js";function C(v){let e,i,r,o,g,m,d,b,u,f,p,y,_;return{c(){e=a("span"),i=l("With the increasing costs of energy and with the current global weather issues,"),r=a("br"),o=l(`
    the need for better, cheaper and eco friendly alternatives is more urgent.`),g=a("br"),m=l(` 
    Searching, developing and replacing classical home heating systems`),d=a("br"),b=l(`
    in the 12th hour is not a feasable feat,`),u=a("br"),f=l(` 
    so we've embarked early on this jurney to becoming leading experts in `),p=a("br"),y=l(` 
    geothermal indoor climate systems using heat exchangers`),_=a("br"),this.h()},l(c){e=s(c,"SPAN",{slot:!0});var t=w(e);i=h(t,"With the increasing costs of energy and with the current global weather issues,"),r=s(t,"BR",{}),o=h(t,`
    the need for better, cheaper and eco friendly alternatives is more urgent.`),g=s(t,"BR",{}),m=h(t,` 
    Searching, developing and replacing classical home heating systems`),d=s(t,"BR",{}),b=h(t,`
    in the 12th hour is not a feasable feat,`),u=s(t,"BR",{}),f=h(t,` 
    so we've embarked early on this jurney to becoming leading experts in `),p=s(t,"BR",{}),y=h(t,` 
    geothermal indoor climate systems using heat exchangers`),_=s(t,"BR",{}),t.forEach($),this.h()},h(){x(e,"slot","left")},m(c,t){B(c,e,t),n(e,i),n(e,r),n(e,o),n(e,g),n(e,m),n(e,d),n(e,b),n(e,u),n(e,f),n(e,p),n(e,y),n(e,_)},p:R,d(c){c&&$(e)}}}function D(v){let e,i,r,o,g,m,d,b,u,f,p,y,_;return{c(){e=a("span"),i=l("With the increasing costs of energy and with the current global weather issues,"),r=a("br"),o=l(`
    the need for better, cheaper and eco friendly alternatives is more urgent.`),g=a("br"),m=l(` 
    Searching, developing and replacing classical home heating systems`),d=a("br"),b=l(`
    in the 12th hour is not a feasable feat,`),u=a("br"),f=l(` 
    so we've embarked early on this jurney to becoming leading experts in `),p=a("br"),y=l(` 
    geothermal indoor climate systems using heat exchangers`),_=a("br"),this.h()},l(c){e=s(c,"SPAN",{slot:!0});var t=w(e);i=h(t,"With the increasing costs of energy and with the current global weather issues,"),r=s(t,"BR",{}),o=h(t,`
    the need for better, cheaper and eco friendly alternatives is more urgent.`),g=s(t,"BR",{}),m=h(t,` 
    Searching, developing and replacing classical home heating systems`),d=s(t,"BR",{}),b=h(t,`
    in the 12th hour is not a feasable feat,`),u=s(t,"BR",{}),f=h(t,` 
    so we've embarked early on this jurney to becoming leading experts in `),p=s(t,"BR",{}),y=h(t,` 
    geothermal indoor climate systems using heat exchangers`),_=s(t,"BR",{}),t.forEach($),this.h()},h(){x(e,"slot","right")},m(c,t){B(c,e,t),n(e,i),n(e,r),n(e,o),n(e,g),n(e,m),n(e,d),n(e,b),n(e,u),n(e,f),n(e,p),n(e,y),n(e,_)},p:R,d(c){c&&$(e)}}}function K(v){let e,i;return e=new z({props:{id:"why",title:"Why",$$slots:{right:[D],left:[C]},$$scope:{ctx:v}}}),{c(){k(e.$$.fragment)},l(r){A(e.$$.fragment,r)},m(r,o){E(e,r,o),i=!0},p(r,[o]){const g={};o&1&&(g.$$scope={dirty:o,ctx:r}),e.$set(g)},i(r){i||(N(e.$$.fragment,r),i=!0)},o(r){P(e.$$.fragment,r),i=!1},d(r){q(e,r)}}}class H extends S{constructor(e){super(),W(this,e,null,K,j,{})}}export{H as default};
